describe('Clinic Summary Tests', () => {
    it('Allows the user to perform various actions on the Clinic Summary page', () => {

        // Navigate to the Clinic Summary page
        cy.visit('http://localhost:3004'); 

        //
    });
    })
        

    
