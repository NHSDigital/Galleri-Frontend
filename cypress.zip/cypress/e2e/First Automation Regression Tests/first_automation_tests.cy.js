// <reference types="cypress" />

describe('Start now', () => {
    it('User clicks on start now button', () => {
        cy.visit("http://localhost:3004")
        .get('.nhsuk-grid-column-two-thirds')
        .contains('Galleri Pilot System')
        .get('.nhsuk-button')
        .click()

        //Verify user is on the clinic summary screen
        cy.get('.nhsuk-grid-row')
        .contains('Clinic Summary')

        //Clinic Summary Screen: User clicks on the dropdown to select the participating ICB
        cy.get('#select-icb')
        .select('Participating ICB QJK')
        .should('have.value', 'Participating ICB QJK')

        //User checks the checkbox to display clinic with no appointments available
        cy.get('#displayClinicsNoApp')
        .click()

        //User select a phlebotomy clinic from the participating ICB
        cy.get('*[id="Phlebotomy clinic 253"]')
         .click()

         //Verify user is on the Clinic Invitation screen
         cy.get('#maincontent')
         .should('have.text','Clinic Information')

         //User clicks on Change clinic link
         cy.get('#changeCancelButtonId')
         .click()

         //User clicks on the dropdown to select another phlebotomy clinic
         cy.get('#clinic-selector')
         .select('Phlebotomy clinic 38')
         .should('have.value','Phlebotomy clinic 38')

          //User clicks on Change clinic link
          cy.get('#changeCancelButtonId')
          .should('have.text','Change clinic')
          .click()

          //User clicks on Cancel change link
          cy.get('#changeCancelButtonId')
          .should('have.text','Cancel change')
          .click()

          //Verify user can see the Clinic Weekly Capacity
          cy.get('.nhsuk-table__caption')
          .should('contain','Clinic Weekly Capacity')

          //User should see the text Clinic Invitation Criteria
          cy.get('#clinic-invitation-criteria-section')
          .should('contain','Clinic Invitation Criteria')

          //User should be able to edit the target percentage of appointments to fill field
          cy.get('#input-target-percentage')
          .clear()
          .type('75')

          //User clicks on update button
          cy.get('#update-button')
          .click()

          //Verify that the distance from the clinic is +1 miles by default
          cy.get('#milesFromSite')
          .contains('+1')


          //User should be able to click on dropdown to select distance from the clinic
           cy.get('#milesFromSite')
           .select(1)
           
           
           // User clicks on Calculate number to invite button
           cy.get('.nhsuk-button')
           .eq(1)
           .click()

           //User should be able to go back to clinic invitations screen from Invitation Summary screen
           cy.get('.nhsuk-back-link__link')
           .click()

           //User should be able to click on go back link on Clinic Invitations Screen
           cy.get('.nhsuk-back-link__link')
           .click()

           //Verify user is on Clinic Invitations screen
           cy.get('.nhsuk-grid-row')
           .should('contain','Clinic Summary')
       

        
    })
})