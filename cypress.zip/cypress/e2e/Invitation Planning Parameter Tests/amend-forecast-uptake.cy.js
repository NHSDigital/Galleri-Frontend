describe('Amend forecast uptake', () => {
    it('Allows the user to amend the forecast uptake', ()=> {

        //Visit the url
        cy.visit('http://localhost:3000');

        // //Verify User is on the Invitation Variables Screen
        // cy.get('.nhsuk-grid-column-full').contains('Invitation variables');

        // //Verify user should see the text National forecast uptake
        // cy.get('.nhsuk-table__caption').contains('National forecast uptake');

        // //User clicks on Amend forecast uptake button
        // cy.get('.nhsuk-button').eq(0).click();

        // //User enters a number in the Current percentage field
        // cy.get('.nhsuk-input').type(35);

        // //User click on save changes button
        // cy.get('.nhsuk-button').eq(0).click();

        // //User should see the current percentage changed to 35%
        // cy.get('.nhsuk-table__cell').contains('35');

        // //User click on cancel without saving
        // //cy.get('.nhsuk-action-link__link:hover .nhsuk-action-link__text').click();

        // //User clicks on Amend forecast uptake button
        // cy.get('.nhsuk-button').eq(0).click();

        // //User enters a number in the Current percentage field
        // cy.get('.nhsuk-input').type(134);

        //  //User click on save changes button
        //  cy.get('.nhsuk-button').eq(0).click();

        //  //User should see the warning message
        //  cy.get('.nhsuk-error-summary').contains('The uptake percentage must not exceed 100%');

        




    })
})  